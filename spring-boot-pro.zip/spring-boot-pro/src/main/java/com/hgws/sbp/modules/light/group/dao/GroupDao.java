package com.hgws.sbp.modules.light.group.dao;

import com.hgws.sbp.commons.base.dao.BaseDao;
import com.hgws.sbp.modules.light.group.entity.Group;

import java.util.List;

public interface GroupDao extends BaseDao<Group> {

}
