package com.hgws.sbp.modules.system.generate.dao;

import com.hgws.sbp.commons.base.dao.BaseDao;

/**
 * @author zhouhonggang
 * @version 1.0.0
 * @project spring-boot-pro
 * @datetime 2022-09-13
 * @description: 一键生成
 */
public interface GeneratorDao extends BaseDao {
}
