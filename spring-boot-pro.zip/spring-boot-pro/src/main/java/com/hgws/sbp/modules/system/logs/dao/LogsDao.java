package com.hgws.sbp.modules.system.logs.dao;

import com.hgws.sbp.commons.base.dao.BaseDao;
import com.hgws.sbp.modules.system.logs.entity.Logs;

/**
 * @author zhouhonggang
 * @version 1.0.0
 * @project spring-boot-pro
 * @datetime 2022-07-01 15:55
 * @description: TODO
 */
public interface LogsDao extends BaseDao<Logs> {
}
