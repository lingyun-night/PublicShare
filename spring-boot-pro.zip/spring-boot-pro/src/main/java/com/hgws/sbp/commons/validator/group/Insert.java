package com.hgws.sbp.commons.validator.group;

/**
 * @author zhouhonggang
 * @version 1.0.0
 * @project spring-boot-pro
 * @datetime 2022-04-13 12:13
 * @description: 校验规则分组·添加
 */
public interface Insert {
}
